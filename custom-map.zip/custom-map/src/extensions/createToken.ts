import {
  type extensionSpec,
  type AppConfig,
  utils,
  createIntl,
  getAppStore,
} from "jimu-core";
import defaultMessage from "../runtime/translations/default";
import CryptoJS from "crypto-js";
import Config from "../../config.json";

import IdentityManager from "@arcgis/core/identity/IdentityManager.js";
import axios from "axios";

export default class createToken
  implements extensionSpec.AppConfigProcessorExtension
{
  id = "createToken";
  widgetId: string;

  async process(appConfig: AppConfig): Promise<AppConfig> {
    // Do not replace when run in builder.
    if (window.jimuConfig.isInBuilder) {
      return Promise.resolve(appConfig);
    }
    const widgetJson = appConfig.widgets[this.widgetId];

    const intl = createIntl({
      locale: getAppStore().getState().appContext.locale,
      messages: Object.assign(
        {},
        defaultMessage,
        widgetJson.manifest.i18nMessages
      ),
    });

    await this.generateToken();

    utils.replaceI18nPlaceholdersInObject(appConfig, intl, defaultMessage);

    return Promise.resolve(appConfig);
  }
  generateToken = async () => {
    debugger;
    const queryParameters = new URLSearchParams(location.search);
    const loginDat = queryParameters.get("data");

    let loginDat1 = loginDat.toString().replaceAll(" ", "+");

    const secretPass = Config.secretPass;
    let decryptedBytes = CryptoJS.AES.decrypt(loginDat1, secretPass);

    let data = decryptedBytes.toString(CryptoJS.enc.Utf8);

    let UserInfo = JSON.parse(data);
    const userData = {
      username: UserInfo[0].username,
      password: UserInfo[0].password,
      referer: "https://ocw-gis.veolia.in", //needs to change to for live
      // referer: "https://localhost:3001/", //for local
      expiration: 1440,
    };
    let result = await axios
      .post(`https://ocw-gis.veolia.in/OCWServer/getToken`, null, {
        params: userData,
      })
      .then(async (data) => {
        if (data.data.result.token && !data.data.error) {
          console.log(data.data.result);

          IdentityManager.registerToken({
            expires: data.data.result.expires,
            server:
              "https://ocw-gis.veolia.in/portal/sharing/rest/generateToken",
            ssl: true,
            token: data.data.result.token,
            userId: UserInfo[0].username,
          });
        } else {
          console.log("Unable to register a token");
          return;
        }
      });
    return result;
  };
}
