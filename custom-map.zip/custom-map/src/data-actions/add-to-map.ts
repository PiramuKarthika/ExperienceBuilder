import {
  AbstractDataAction, type DataRecordSet, getAppStore, type ImmutableObject, type JimuMapViewInfo, defaultMessages,
  MutableStoreManager, utils, i18n, type JSAPILayerMixin, type DataSource, DataSourceTypes, DataSourceStatus
} from 'jimu-core'
import { MapViewManager, ADD_TO_MAP_DATA_ID_PREFIX, ActionType, DataChangeType, DataChangeStatus, zoomToUtils } from 'jimu-arcgis'

export default class AddToMap extends AbstractDataAction {
  private readonly _viewManager = MapViewManager.getInstance()

  async isSupported (dataSet: DataRecordSet): Promise<boolean> {
    const dataSource = dataSet?.dataSource as DataSource & JSAPILayerMixin
    const activeViewId = this._getActiveViewId(this.widgetId, getAppStore().getState().jimuMapViewsInfo)
    const jimuMapView = this._viewManager.getJimuMapViewById(activeViewId)
    if (!dataSource || dataSource.getStatus() === DataSourceStatus.NotReady) {
      return false
    }
    if ((dataSource.type === DataSourceTypes.SceneLayer || dataSource.type === DataSourceTypes.SceneService) && jimuMapView?.view?.type === '2d') {
      // add a scene layer to a 2d map
      return false
    } else {
      return dataSource?.supportSpatialInfo &&
             dataSource?.supportSpatialInfo() &&
             !!dataSource?.createJSAPILayerByDataSource &&
             !dataSource.isInAppConfig() &&
             dataSet.records?.length === 0
    }
  }

  async onExecute (dataSet: DataRecordSet, actionConfig?: any): Promise<boolean> {
    const activeViewId = this._getActiveViewId(this.widgetId, getAppStore().getState().jimuMapViewsInfo)
    const addToMapDatas = MutableStoreManager.getInstance().getStateValue([this.widgetId])?.addToMapDatas || {}
    const intl = i18n.getIntl()
    const dataSetName = dataSet.name || ''
    const name = intl.formatMessage({ id: 'action_addedData', defaultMessage: defaultMessages.action_addedData }, { label: dataSetName })
    // save action data
    const id = `${ADD_TO_MAP_DATA_ID_PREFIX}dataAction_${utils.getUUID()}`
    addToMapDatas[id] = {
      mapWidgetId: this.widgetId,
      jimuMapViewId: activeViewId,
      dataSourceId: dataSet.dataSource.id,
      type: ActionType.DataAction,
      dataChangeType: DataChangeType.Create,
      dataChangeStatus: DataChangeStatus.Pending,
      title: name
    }
    MutableStoreManager.getInstance().updateStateValue(this.widgetId, 'addToMapDatas', addToMapDatas)

    const jimuMapView = this._viewManager.getJimuMapViewById(activeViewId)
    if (jimuMapView) {
      (dataSet.dataSource as unknown as JSAPILayerMixin)?.createJSAPILayerByDataSource().then(layer => {
        zoomToUtils.zoomTo(jimuMapView?.view, layer, {
          padding: {
            left: 50,
            right: 50,
            top: 50,
            bottom: 50
          }
        })
      })
    }
    return await Promise.resolve(true)
  }

  private _getActiveViewId (mapWidgetId: string, infos: ImmutableObject<{ [jimuMapViewId: string]: JimuMapViewInfo }>): string {
    let activeViewId = Object.keys(infos || {}).find(viewId => infos[viewId].mapWidgetId === mapWidgetId && infos[viewId].isActive)
    // using a default map view as active map view if the widget hasn't been loaded.
    if (!activeViewId) {
      activeViewId = Object.keys(infos || {}).find(viewId => infos[viewId].mapWidgetId === mapWidgetId)
    }
    return activeViewId
  }
}
