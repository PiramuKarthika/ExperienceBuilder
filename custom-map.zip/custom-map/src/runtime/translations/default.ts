export default {
  _widgetLabel: 'Map',
  _action_displayFeatureSet_label: 'Display feature set',
  _action_panTo_label: 'Pan to',
  _action_zoomToFeature_label: 'Zoom to',
  _action_selectFeature_label: 'Select feature',
  _action_flash_label: 'Flash',
  _action_filter_label: 'Filter',
  _action_showOnMap_label: 'Show on map',
  _action_addToMap_label: 'Add to map',
  showOnMapData: 'Show on map data',
  addedData: 'added data',
  failToAddTheDataOnMap: 'Fail to add the data.',
  addToMapData: 'Add to map data'
}
