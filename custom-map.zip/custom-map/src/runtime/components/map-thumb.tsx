import { React, SessionManager, esri, getAppStore, type IMThemeVariables } from 'jimu-core'
import { ImageWithParam } from 'jimu-ui'
import { PlaceholderMapFilled } from 'jimu-icons/filled/data/placeholder-map'
import CryptoJS from "crypto-js";
import Config from "../../../config.json";

import IdentityManager from "@arcgis/core/identity/IdentityManager.js";
import axios from "axios";
import esriConfig from "@arcgis/core/config.js";


interface Props {
  mapItemId: string
  portUrl: string
  theme: IMThemeVariables
}

interface States {
  mapThumbUrl: string
}

export default class MapThumb extends React.PureComponent<Props, States> {
  unmount = false

  constructor(props) {
    super(props)

    this.state = {
      mapThumbUrl: null
    }
  } 

  componentDidMount() {
    this.unmount = false
    this.setMapThumbUrl(this.props.mapItemId)
  }

  componentDidUpdate(prevProps: Props, prevState) {
    if (prevProps.mapItemId !== this.props.mapItemId) {
      this.setMapThumbUrl(this.props.mapItemId)
    }
  }

  setMapThumbUrl = async (mapId: string): void => {
    if (!mapId) {
      this.setState({ mapThumbUrl: null })
    }

    // if no portalUrl or same to config portalurl, use app config's portalUrl
    const portalUrl = this.props?.portUrl || getAppStore().getState().portalUrl
    const session = SessionManager.getInstance().getSessionByUrl(portalUrl) || null;
    const queryParameters = new URLSearchParams(location.search);
    const loginDat = queryParameters.get("data");

    let loginDat1 = loginDat.toString().replaceAll(" ", "+");
    // const role = queryParameters.get('role');


    const secretPass = Config.secretPass;
    let decryptedBytes = CryptoJS.AES.decrypt(loginDat1, secretPass);

    let data = decryptedBytes.toString(CryptoJS.enc.Utf8);

    let UserInfo = JSON.parse(data);
    const userData = {
      username: UserInfo[0].username,
      password: UserInfo[0].password,
      referer: "https://ocw-gis.veolia.in/OCWApplication",//needs to change to for live
      //referer: "https://localhost:3001/",//for local
      expiration: 1440,
    };
    esriConfig.portalUrl = 'https://ocw-gis.veolia.in/portal';
   // let response = await this.generateToken(UserInfo, userData);

    esri.restPortal.searchItems({
      q: `id:${mapId}`,
      authentication: session,
      portal: portalUrl + '/sharing/rest'
    }).then(items => {
      if (!this.unmount) {
        if (items.results[0]?.thumbnail) {
          const session = SessionManager.getInstance().getSessionByUrl(portalUrl)
          //let token = response.token ? response.token : session.token;
          // session.token = response.token;
          let tempThumbUrl = null
          if (session && session.token) {
            tempThumbUrl = `${portalUrl}/sharing/rest/content/items/${items.results[0].id}/` +
              `info/${items.results[0].thumbnail}?token=${session.token}`
          } else {
            tempThumbUrl = `${portalUrl}/sharing/rest/content/items/${items.results[0].id}/` +
              `info/${items.results[0].thumbnail}`
          }

          this.setState({ mapThumbUrl: tempThumbUrl })
        } else {
          this.setState({ mapThumbUrl: null })
        }
      }
    })
  }

  generateToken = async (UserInfo, userData) => {
    let result = await axios
      .post(`https://ocw-gis.veolia.in/OCWServer/generateToken`, null, {
        params: userData,
      })
      .then(async (data) => {
        // .then(async (data) => {
        if (data.data.result.token && !data.data.error) {
          await IdentityManager.registerToken({
            expires: data.data.result.expires,
            server: "https://ocw-gis.veolia.in/portal/sharing/rest",
            ssl: true,
            token: data.data.result.token,
            userId: UserInfo[0].username,
          });
          return data.data.result
        }
        else {
          console.log('Unable to register a token')
          return;
        }
      });
    return result;
  }

  componentWillUnmount() {
    this.unmount = true
  }

  render() {
    if (this.state.mapThumbUrl) {
      return <ImageWithParam imageParam={{ url: this.state.mapThumbUrl }} />
    } else {
      const palette = this.props.theme.colors.palette
      return (<div style={{ backgroundColor: palette.light[200], height: '100%' }} >
        <PlaceholderMapFilled color={palette.light[600]} size={'100%'} />
      </div>)
    }
  }
}
